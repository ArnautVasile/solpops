const bodyParser = require('body-parser');
const cors = require('cors');
const express = require('express');
const app = express();
const mysql = require('mysql');

const db = mysql.createPool({
    host: 'localhost',
    user: 'mcx',
    password: 'init1234',
    database: 'solpops'
});

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));

app.post("/api/add/collection/", (req, res) => {
    const addCollection = "INSERT INTO Collections (collection) VALUES (?)";
    db.query(addCollection, [req.body.name], (err, resp) => { 
        res.send(resp);
        console.log(err);
    });
});

app.post("/api/rm/collection/", (req, res) => {
    const rmCollection = "DELETE FROM Collections WHERE collection = (?)";
    
    db.query(rmCollection, [req.body.name], (err, resp) => { 
        res.send(resp);
        console.log(err);
    });
});

app.post("/api/get/collections/", (req, res) => {
    const getCollections = "SELECT * FROM Collections";
    
    db.query(getCollections, (err, resp) => { 
        res.send(resp);
    });
});

app.post("/api/add/nft/", (req, res) => {
    

    const addNfts = "INSERT INTO Nfts (nft_name, nft_address, nft_collection, nft_burned) VALUES (?, ?, ?, ?)";
    
    db.query(addNfts, [req.body.nft_name, req.body.nft_address, req.body.nft_collection, req.body.nft_burned], (err, resp) => { 
        res.send(resp);
        console.log(err);
    });
});

app.post("/api/rm/nft/", (req, res) => {
    const rmNft = "DELETE FROM Nfts WHERE id = (?)";
    
    db.query(rmNft, [req.body.id], (err, resp) => { 
        res.send(resp);
        console.log(err);
    });
});

app.post("/api/get/nfts/", (req, res) => {
    const getNfts = "SELECT * FROM Nfts";
    
    db.query(getNfts, (err, resp) => { 
        res.send(resp);
    });
});

app.listen(3001, () => {
     console.log('hi there'); 
});